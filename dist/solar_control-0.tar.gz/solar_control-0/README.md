# Control's
This package aim to provide tools for solar forecasting, probabilistic modeling and probabilistic dynamic programming
 * To install download the repository ad run the following command in terminal *pip install control --no-index 
   --find-links system_control/dist*
 * To see help got to this link https://htmlpreview.github.io/?https://github.com/Faly4/system_control/blob/1dcf30f31039b9291c3010e661d6e0d532f849a6/_build/html/index.html
