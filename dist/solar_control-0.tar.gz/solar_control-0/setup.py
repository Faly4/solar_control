from setuptools import setup

setup(
    name='solar_control',
    version='0',
    packages=['pdp', 'pv_solar', 'dev_tools'],
    url='',
    license='',
    author='Faly Ramahatana',
    author_email='faly.ramahatana-andriamasomanana@univ-reunion.fr',
    description='',
    include_package_data=True,
    package_data={'': ['pv_solar/data/*']}
)
