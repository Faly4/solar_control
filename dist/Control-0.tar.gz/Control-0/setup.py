from setuptools import setup

setup(
    name='Control',
    version='0',
    packages=['pdp', 'solar', 'dev_tools'],
    url='',
    license='',
    author='Faly Ramahatana',
    author_email='faly.ramahatana-andriamasomanana@univ-reunion.fr',
    description=''
)
