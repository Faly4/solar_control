# Control's
This package aim to provide tools for solar forecasting, probabilistic modeling and probabilistic dynamic programming.# climato
 * To see the program and its feature, open a terminal and run  *"control0/_build/html/index.html"*.
 * To test the examples in the package, *control0/* must be set as the current directory 
